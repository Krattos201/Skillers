from django.contrib import admin
from .models import person

admin.site.register(person)

# Register your models here.
