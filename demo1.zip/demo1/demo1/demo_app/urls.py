
from django.urls import path
from . import views

urlpatterns = [
    path('',views.login, name='login'),
    path('Welcome/',views.welcome, name='welcome'),
    path('redirect_login',views.redirect_login,name='redirect_login'),
    path('redirect_register',views.redirect_register,name='redirect_register'),
    path('page1',views.page1, name='page1'),
    path('page2',views.page2, name='page2'),
    path('page3',views.page3, name='page3'),
]
