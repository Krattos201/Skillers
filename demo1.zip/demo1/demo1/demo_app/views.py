from django.shortcuts import render, redirect, render_to_response
from django.http import HttpResponse,HttpResponseRedirect

def login(request):
	return render(request,"login.html",{})

def welcome(request,var):
	var1=var
	return render(request,"welcome.html",{"Mystuff":var})

def redirect_login(request):
	return HttpResponseRedirect('http://localhost:8084')

def redirect_register(request):
	
	return HttpResponseRedirect('http://localhost:8084/About')

def page1(request):
	return render(request,"page1.html",{})

def page2(request):
	return render(request,"page2.html",{})

def page3(request):
	return render(request,"page3.html",{})