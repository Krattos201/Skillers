from django.apps import AppConfig


class DemoAppConfig(AppConfig):
    name = 'demo_app'


class MyAppConfig(AppConfig):
	name = 'myapp'

def ready(self):
	from . import handlers